Name: Sree Venkata Prathyusha Vudatha
Email: svudath1@binghamton.edu

Compiling the code:
gcc vudatha_prathyusha_pa2_strassens.c -o strassens.out
gcc vudatha_prathyusha_pa2_heap_radix.c -o heap_radix.out
gcc vudatha_prathyusha_pa2_lim.c -o lim.out


Running the code:
./strassens.out
./heap_radix.out
./lim.out